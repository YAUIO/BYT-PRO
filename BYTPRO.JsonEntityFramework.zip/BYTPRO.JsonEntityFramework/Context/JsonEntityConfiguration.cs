﻿namespace BYTPRO.JsonEntityFramework.Context;

public record JsonEntityConfiguration(Type Target, string? FileName);